package com.example.firstapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Set;

public class Ble_Scan_Screen extends AppCompatActivity {

    Button buttonScan;

    ListView listView;

    BluetoothAdapter myBluetoothAdapter;

    TextView pairedDevice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ble_scan_screen);
        buttonScan = (Button) findViewById(R.id.btnScan);
        listView = (ListView) findViewById(R.id.myListView);
        pairedDevice = (TextView) findViewById(R.id.textView);

        myBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

//        ArrayList<String> grocery = new ArrayList<>();
//        grocery.add("Surfexcel");
//        grocery.add("Chocos");
//        grocery.add("Lays");
//
//        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, grocery);
//        listView.setAdapter(arrayAdapter);

        executeButton();


    }

    private void executeButton() {
        buttonScan.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (myBluetoothAdapter.isEnabled()) {
//                    pairedDevice.setText("Paired Devices");
                    if (ActivityCompat.checkSelfPermission(Ble_Scan_Screen.this, android.Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED) {
                        // TODO: Consider calling
                        //    ActivityCompat#requestPermissions
                        // here to request the missing permissions, and then overriding
                        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                        //                                          int[] grantResults)
                        // to handle the case where the user grants the permission. See the documentation
                        // for ActivityCompat#requestPermissions for more details.
                        return;
                    }

                    Set<BluetoothDevice> bt = myBluetoothAdapter.getBondedDevices();

                    String[] strings = new String[bt.size()];
                    int index = 0;


                    if(bt.size()>0){
                        for (BluetoothDevice device:bt){
                        strings[index]=device.getName();
                        index++;
                    }

                    //creating array adapter
                    ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(Ble_Scan_Screen.this, android.R.layout.simple_list_item_1, strings);
                    listView.setAdapter(arrayAdapter);
        }

                }
                Log.d("button clicked", "clicked");



            }
        });
    }
}

//    Set<BluetoothDevice> bt = myBluetoothAdapter.getBondedDevices();
//
//    String[] strings = new String[bt.size()];
//    int index = 0;
//
//
//            if(bt.size()>0){
//                    for (BluetoothDevice device:bt){
//                    strings[index]=device.getName();
//                    index++;
//                    }
//
//                    //creating array adapter
//                    ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(Ble_Scan_Screen.this, android.R.layout.simple_list_item_1, strings);
//        listView.setAdapter(arrayAdapter);
//        }



//                if (ActivityCompat.checkSelfPermission(Ble_Scan_Screen.this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
//                    // TODO: Consider calling
//                    //    ActivityCompat#requestPermissions
//                    // here to request the missing permissions, and then overriding
//                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//                    //                                          int[] grantResults)
//                    // to handle the case where the user grants the permission. See the documentation
//                    // for ActivityCompat#requestPermissions for more details.
//                    return;
//                }
//                Set<BluetoothDevice> bt = myBluetoothAdapter.getBondedDevices();

//                String[] strings = new String[bt.size()];
//                int index = 0;
//
//
//                if(bt.size()>0){
//                    for (BluetoothDevice device:bt){
//                        strings[index]=device.getName();
//                        index++;
//                    }
//
//                    //creating array adapter
//                    ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, strings);
//                    listView.setAdapter(arrayAdapter);
//                }