package com.example.firstapplication;

import static android.Manifest.permission.BLUETOOTH;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Ble_Screen extends AppCompatActivity {

    Button buttonON, buttonOFF, buttonScan;
    BluetoothAdapter myBluetoothAdapter;

    Intent btEnablingIntent;
    int requestCodeForEnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ble_screen);

        buttonON = (Button) findViewById(R.id.btnOn);
        buttonOFF = (Button) findViewById(R.id.btnOff);
        buttonScan = (Button) findViewById(R.id.btnScanPage);
        myBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

//        enabling bluetooth
        btEnablingIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        requestCodeForEnable = 1;

        bluetoothONMethod();
        bluetoothOFFMethod();
        goToScanPageMethod();
    }

    private void goToScanPageMethod() {
        buttonScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Ble_Screen.this, Ble_Scan_Screen.class);
                startActivity(intent);
            }
        });
    }

    private void bluetoothOFFMethod() {
        buttonOFF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myBluetoothAdapter.isEnabled()) {
                    if (ActivityCompat.checkSelfPermission(Ble_Screen.this, BLUETOOTH) != PackageManager.PERMISSION_GRANTED) {
                        // TODO: Consider calling
                        //    ActivityCompat#requestPermissions
                        // here to request the missing permissions, and then overriding
                        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                        //                                          int[] grantResults)
                        // to handle the case where the user grants the permission. See the documentation
                        // for ActivityCompat#requestPermissions for more details.
                        return;
                    }
                    Intent intent = new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
                    startActivity(intent);
                }
            }
        });
    }

//    for result override a method
//    ctrl+o & type onActivityResult

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == requestCodeForEnable) {
            if (resultCode == RESULT_OK) {
                Intent intent = new Intent(Ble_Screen.this, Ble_Scan_Screen.class);
                startActivity(intent);
                Toast.makeText(getApplicationContext(), "Bluetooth is Enable", Toast.LENGTH_LONG).show();
            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText((getApplicationContext()), "Bluetooth Enabling Canceled", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void bluetoothONMethod() {
        buttonON.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if(myBluetoothAdapter==null){
                    Toast.makeText(getApplicationContext(),"Bluetooth Does not support on this Device", Toast.LENGTH_LONG).show();
                }else{
//
                    if(!myBluetoothAdapter.isEnabled()){
                        startActivityForResult(btEnablingIntent, requestCodeForEnable);

                    }
                }
            }
        });
    }
}